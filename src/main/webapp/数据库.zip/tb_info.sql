INSERT INTO dsscm.tb_info (id, infoCode, providerName, creationDate, content) VALUES (1, '0005', '张三', '2024-05-04 15:01:26', '张三来信');
INSERT INTO dsscm.tb_info (id, infoCode, providerName, creationDate, content) VALUES (2, '0004', '李四', '2024-07-04 19:38:40', '李四来信');
INSERT INTO dsscm.tb_info (id, infoCode, providerName, creationDate, content) VALUES (3, '0003', '王五', '2020-05-04 19:41:19', '王五来信');
INSERT INTO dsscm.tb_info (id, infoCode, providerName, creationDate, content) VALUES (4, '0002', '阿白', '2020-05-04 19:41:55', '阿白来信');
INSERT INTO dsscm.tb_info (id, infoCode, providerName, creationDate, content) VALUES (6, '0001', 'momo', '2023-05-04 19:42:59', 'momo来信');

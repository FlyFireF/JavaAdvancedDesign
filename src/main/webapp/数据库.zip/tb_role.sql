INSERT INTO dsscm.tb_role (id, roleCode, roleName, createdBy, creationDate, modifyBy, modifyDate) VALUES (1, 'DSSCM_ADMIN', '系统管理员', 1, '2019-08-13 00:00:00', 1, '2019-11-03 11:00:44');
INSERT INTO dsscm.tb_role (id, roleCode, roleName, createdBy, creationDate, modifyBy, modifyDate) VALUES (2, 'DSSCM_MANAGER', '经理', 1, '2019-08-13 00:00:00', null, null);
INSERT INTO dsscm.tb_role (id, roleCode, roleName, createdBy, creationDate, modifyBy, modifyDate) VALUES (3, 'DSSCM_EMPLOYEE', '普通员工1', 1, '2019-08-13 00:00:00', 1, '2024-05-07 19:26:53');
INSERT INTO dsscm.tb_role (id, roleCode, roleName, createdBy, creationDate, modifyBy, modifyDate) VALUES (4, 'DSSCM_PERSONNEL', '人事部员工', 1, '2019-11-01 23:37:21', null, null);
INSERT INTO dsscm.tb_role (id, roleCode, roleName, createdBy, creationDate, modifyBy, modifyDate) VALUES (5, 'DSSCM_PURCHASE', '采购部员工', 1, '2019-11-01 23:37:21', null, null);
INSERT INTO dsscm.tb_role (id, roleCode, roleName, createdBy, creationDate, modifyBy, modifyDate) VALUES (6, 'DSSCM_MATERIAL', '物资部员工', 1, '2019-11-01 23:37:22', null, null);
INSERT INTO dsscm.tb_role (id, roleCode, roleName, createdBy, creationDate, modifyBy, modifyDate) VALUES (7, 'DSSCM_SALES', '销售部员工', 1, '2019-11-01 23:37:23', null, null);
INSERT INTO dsscm.tb_role (id, roleCode, roleName, createdBy, creationDate, modifyBy, modifyDate) VALUES (10, 'dsscm_123', '员工123', 1, '2019-11-04 09:02:36', 1, '2024-05-24 22:15:05');
